export class TipoSangre
{
    public IdTipoSangre:number;
    public Nombre:string;
}