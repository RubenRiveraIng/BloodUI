export class SolicitudRecoleccion {
    public IdSolicitud: number;
    public Direccion_Donde: string;
    public LGN_Donde: string;
    public LTD_Donde: string;
    public  IdEstado_Solicitud : number;
    public  IdUsuario_Solicita : number;
    public  IdUsuario_Recolecta: number;
    public  Fecha_Recoleccion :Date;
}