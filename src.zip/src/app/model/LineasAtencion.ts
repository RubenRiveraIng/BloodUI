export class LineasAtencion{

    public  IdLineas_Atencion:string;
    public  Nombre :string;
    public  Descripcion :string;
    public  Telefono_1 :string;
    public  Telefono_2 :string;
    public  Telefono_3 :string;
    public  Telefono_4 :string;
    public  Telefono_5 :string;
}