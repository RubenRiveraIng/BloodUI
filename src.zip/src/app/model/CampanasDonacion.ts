export class CampanasDonacion {

    public IdCampanas_Donacion: number;
    public Nombre: string;
    public Descripcion: string;
    public Direccion: string;
    public LNG: string;
    public LTD: string;
    public Fecha_Inicio: Date;
    public Fecha_Fin : Date;
    public IdUsuario:number;
    public Telefono_1 :string;
    public Telefono_2:string ;
    public Email :string;
}