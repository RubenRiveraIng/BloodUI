export class JoinSolicitud {
    public IdSolicitud: number;
    public NombreEntidad: string;
    public NombreSolicitante: string;
    public Direccion: string;
    public Fecha_Recoleccion: Date;
    public IdEstado_Solicitud: number;
    public strEstado_Solicitud: string;
    public LNG: string;
    public LTD: string;
}