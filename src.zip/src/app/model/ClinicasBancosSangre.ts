export class ClinicasBancosSangre {
    public Idclinicas_Bancos_Sangre: number;
    public Nombre: string;
    public Descripcion: string;
    public Direccion: string;
    public LNG: string;
    public LTD: string;
    public Telefono_1: string;
    public Telefono_2: string;
    public Telefono_3: string;
    public IdUsuario: number;
}