export class Menu
{
    public IdMenu:number;
    public Nombre:string;
    public Descripcion:string;
    public Icono :string;
    public urlRedirect: string;
}