export class TipoDocumento
{
    public  IdTipoDocumento:number;
    public Nombre:string;
}