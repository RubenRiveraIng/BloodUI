import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-solicitarrecoleccion',
  templateUrl: './solicitarrecoleccion.page.html',
  styleUrls: ['./solicitarrecoleccion.page.scss'],
})
export class SolicitarrecoleccionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
