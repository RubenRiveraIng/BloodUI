import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-campanasdonacion',
  templateUrl: './campanasdonacion.page.html',
  styleUrls: ['./campanasdonacion.page.scss'],
})
export class CampanasdonacionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
