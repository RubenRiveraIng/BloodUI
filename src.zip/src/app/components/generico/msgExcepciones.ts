export class msgExcepciones{
    public msgErrorCampos:string="Recuerde, todos los campos son obligatorios";
    public msgErrorCamposEspecificos:string="El campo @campo es obligatorio";
    public msgErrorCampoContraseña:string="El campo contraseña es obligatorio, recuerde que debe tener minimo 8 caracteres";
    public msgErrorCampoEmail:string="Correo electronico invalido";

}