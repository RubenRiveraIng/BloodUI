export class Validaciones
{
    
}