import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-codicionesdonacion',
  templateUrl: './codicionesdonacion.page.html',
  styleUrls: ['./codicionesdonacion.page.scss'],
})
export class CodicionesdonacionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
